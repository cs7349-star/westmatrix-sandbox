# AI-Powered Business Assistant

Streamlit RAG application for business document analysis.

Features:
- PDF, DOCX, TXT upload
- RAG question answering
- Document summaries
- Conversation history
- Error handling

Run:

pip install -r requirements.txt

streamlit run app.py

Architecture:

Document -> Loader -> Embeddings -> FAISS -> LLM -> Answer
