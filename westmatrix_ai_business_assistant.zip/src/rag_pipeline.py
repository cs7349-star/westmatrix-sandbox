from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.chains import RetrievalQA

def build_rag(text):
    docs=RecursiveCharacterTextSplitter(chunk_size=1000,chunk_overlap=100).create_documents([text])
    db=FAISS.from_documents(docs,OpenAIEmbeddings())
    return RetrievalQA.from_chain_type(
        llm=ChatOpenAI(model="gpt-4o-mini"),
        retriever=db.as_retriever(),
        return_source_documents=True
    )

def ask_question(chain,q):
    r=chain.invoke({"query":q})
    return r["result"]

def summarize_document(text):
    return ChatOpenAI(model="gpt-4o-mini").invoke("Summarize:\n"+text[:5000]).content
