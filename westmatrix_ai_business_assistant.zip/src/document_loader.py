from PyPDF2 import PdfReader
from docx import Document

def load_document(file):
    if file.size == 0:
        raise ValueError("Empty file")

    if file.name.endswith(".pdf"):
        return "\n".join(p.extract_text() or "" for p in PdfReader(file).pages)

    if file.name.endswith(".docx"):
        return "\n".join(p.text for p in Document(file).paragraphs)

    if file.name.endswith(".txt"):
        return file.read().decode()

    raise ValueError("Unsupported file")
