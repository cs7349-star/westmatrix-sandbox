import streamlit as st
from src.document_loader import load_document
from src.rag_pipeline import build_rag, ask_question, summarize_document

st.title("AI-Powered Business Assistant")

if "chat" not in st.session_state:
    st.session_state.chat=[]

if st.button("Clear Session"):
    st.session_state.chat=[]

file=st.file_uploader("Upload document", type=["pdf","docx","txt"])

if file:
    text=load_document(file)
    chain=build_rag(text)

    st.subheader("Summary")
    st.write(summarize_document(text))

    q=st.text_input("Ask a question")
    if q:
        a=ask_question(chain,q)
        st.session_state.chat.append((q,a))

    for q,a in st.session_state.chat:
        st.write("Q:",q)
        st.write("A:",a)
