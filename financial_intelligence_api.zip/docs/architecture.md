# Architecture

```text
Client
  |
  v
FastAPI /snapshot/{ticker}
  |---- Yahoo Finance
  |---- FRED
  v
Standardization Layer
  v
AI Summary Layer
  v
JSON Response + Sources + Warnings
```
