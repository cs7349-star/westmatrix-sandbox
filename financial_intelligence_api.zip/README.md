# Financial Intelligence API & AI Summary Layer

## Setup
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

## Run
```bash
uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000/docs`

Examples:
- `GET /snapshot/NVDA`
- `GET /snapshot/AAPL`
- `GET /snapshot/MSFT`

Outputs include standardized Yahoo Finance market data, FRED GDP/CPI/unemployment data, source attribution, AI summary, and warnings.

See `docs/architecture.md` and `docs/executive_summary.md`.
