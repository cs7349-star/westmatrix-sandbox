import os
from datetime import datetime, timezone
from typing import Any, Optional
import requests
import yfinance as yf
from fastapi import FastAPI, HTTPException
from openai import OpenAI

app = FastAPI(title="Financial Intelligence API", version="1.0.0")
FRED_API_KEY = os.getenv("FRED_API_KEY")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
client = OpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None

def now_iso():
    return datetime.now(timezone.utc).isoformat()

def safe_float(value: Any) -> Optional[float]:
    try:
        return None if value in (None, "") else float(value)
    except (TypeError, ValueError):
        return None

def record(source, metric, value, units, frequency, symbol=None, timestamp=None):
    return {"data_source":source,"timestamp":timestamp or now_iso(),"symbol":symbol,
            "metric_name":metric,"metric_value":value,"units":units,"frequency":frequency}

def get_market_data(ticker):
    t = yf.Ticker(ticker)
    info = t.info
    hist = t.history(period="5d")
    if hist.empty:
        raise ValueError("No market data returned")
    current = safe_float(info.get("currentPrice"))
    if current is None:
        current = safe_float(hist["Close"].dropna().iloc[-1])
    return {
        "company_name": info.get("longName") or ticker.upper(),
        "ticker": ticker.upper(),
        "records": [
            record("Yahoo Finance","Current Price",current,"USD","daily",ticker.upper()),
            record("Yahoo Finance","Previous Close",safe_float(info.get("previousClose")),"USD","daily",ticker.upper()),
            record("Yahoo Finance","Market Capitalization",safe_float(info.get("marketCap")),"USD","daily",ticker.upper()),
            record("Yahoo Finance","52 Week High",safe_float(info.get("fiftyTwoWeekHigh")),"USD","daily",ticker.upper()),
            record("Yahoo Finance","52 Week Low",safe_float(info.get("fiftyTwoWeekLow")),"USD","daily",ticker.upper())
        ]
    }

def fred_latest(series_id, metric_name, units, frequency):
    if not FRED_API_KEY:
        raise ValueError("Missing FRED_API_KEY")
    r = requests.get("https://api.stlouisfed.org/fred/series/observations",
        params={"series_id":series_id,"api_key":FRED_API_KEY,"file_type":"json","sort_order":"desc","limit":10},
        timeout=10)
    r.raise_for_status()
    obs = r.json().get("observations", [])
    valid = next((o for o in obs if safe_float(o.get("value")) is not None), None)
    if not valid:
        raise ValueError(f"No valid FRED data for {series_id}")
    return record("FRED",metric_name,safe_float(valid["value"]),units,frequency,series_id,valid.get("date"))

def build_summary(company_name, ticker, records):
    if client is None:
        return "AI summary unavailable because OPENAI_API_KEY is not configured."
    lines = [f"{r['metric_name']}: {r['metric_value']} {r['units']} (source: {r['data_source']})" for r in records]
    prompt = f"Write a concise business summary for {company_name} ({ticker}) using only this data. Keep under 130 words.\n" + "\n".join(lines)
    return client.responses.create(model="gpt-5-mini", input=prompt).output_text

@app.get("/")
def root():
    return {"service":"Financial Intelligence API","status":"ok"}

@app.get("/snapshot/{ticker}")
def snapshot(ticker: str):
    ticker = ticker.strip().upper()
    if not ticker:
        raise HTTPException(status_code=400, detail="Ticker is required")
    try:
        market = get_market_data(ticker)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Market data unavailable: {exc}")
    macro, warnings = [], []
    for args in [
        ("GDP","Gross Domestic Product","Billions of Dollars","quarterly"),
        ("CPIAUCSL","Consumer Price Index","Index 1982-1984=100","monthly"),
        ("UNRATE","Unemployment Rate","Percent","monthly")
    ]:
        try:
            macro.append(fred_latest(*args))
        except Exception as exc:
            warnings.append(str(exc))
    records = market["records"] + macro
    return {
        "ticker":ticker,
        "company_name":market["company_name"],
        "generated_at":now_iso(),
        "financial_snapshot":records,
        "ai_summary":build_summary(market["company_name"], ticker, records),
        "sources":sorted(list({r["data_source"] for r in records})),
        "warnings":warnings
    }
