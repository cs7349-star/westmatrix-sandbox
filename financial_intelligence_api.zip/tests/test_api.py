from fastapi.testclient import TestClient
from unittest.mock import patch
from app.main import app

client = TestClient(app)

def test_root():
    r = client.get("/")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"

@patch("app.main.get_market_data")
@patch("app.main.fred_latest")
@patch("app.main.build_summary")
def test_snapshot(mock_summary, mock_fred, mock_market):
    mock_market.return_value = {
        "company_name":"Test Company","ticker":"TEST",
        "records":[{"data_source":"Yahoo Finance","timestamp":"2026-09-03T00:00:00+00:00","symbol":"TEST","metric_name":"Current Price","metric_value":100.0,"units":"USD","frequency":"daily"}]
    }
    mock_fred.side_effect = [
        {"data_source":"FRED","timestamp":"2026-01-01","symbol":"GDP","metric_name":"Gross Domestic Product","metric_value":30000.0,"units":"Billions of Dollars","frequency":"quarterly"},
        {"data_source":"FRED","timestamp":"2026-07-01","symbol":"CPIAUCSL","metric_name":"Consumer Price Index","metric_value":320.0,"units":"Index 1982-1984=100","frequency":"monthly"},
        {"data_source":"FRED","timestamp":"2026-07-01","symbol":"UNRATE","metric_name":"Unemployment Rate","metric_value":4.2,"units":"Percent","frequency":"monthly"}
    ]
    mock_summary.return_value = "Test summary."
    r = client.get("/snapshot/TEST")
    assert r.status_code == 200
    assert r.json()["ticker"] == "TEST"
